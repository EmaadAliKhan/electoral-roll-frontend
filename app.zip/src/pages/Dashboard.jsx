import React, { useEffect, useState } from 'react';
import apiClient from '../api/axiosConfig';
import Card from '../components/common/Card';
import { Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';
import '../assets/css/Dashboard.css';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [countRes, genderRes, ageRes] = await Promise.all([
          apiClient.get('/voters/count'),
          apiClient.get('/analysis/gender'),
          apiClient.get('/analysis/age-groups')
        ]);
        setStats({
          totalVoters: countRes.data.count,
          gender: genderRes.data,
          ageGroups: ageRes.data,
        });
      } catch (error) {
        console.error("Failed to fetch dashboard data", error);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboardData();
  }, []);

  if (loading) return <div>Loading Dashboard...</div>;
  if (!stats) return <div>No data available.</div>;

  const genderChartData = {
    labels: Object.keys(stats.gender).filter(k => k !== 'married_women'),
    datasets: [{
      data: Object.values(stats.gender).filter((v, i) => Object.keys(stats.gender)[i] !== 'married_women'),
      backgroundColor: ['#4A90E2', '#FF6B6B', '#F8E71C'],
    }]
  };
  
  const ageGroupChartData = {
    labels: Object.keys(stats.ageGroups),
    datasets: [{
      label: 'Voters by Age',
      data: Object.values(stats.ageGroups),
      backgroundColor: 'rgba(74, 144, 226, 0.7)',
    }]
  };

  return (
    <div className="dashboard-grid">
      <Card title="Total Voters">
        <div className="stat-number">{stats.totalVoters.toLocaleString()}</div>
      </Card>
      <Card title="Married Women">
        <div className="stat-number">{stats.gender.married_women?.toLocaleString() || 0}</div>
      </Card>
      <Card title="Gender Distribution">
        <Pie data={genderChartData} />
      </Card>
      <Card title="Voter Age Groups">
        <Bar data={ageGroupChartData} options={{ responsive: true }} />
      </Card>
    </div>
  );
};

export default Dashboard;