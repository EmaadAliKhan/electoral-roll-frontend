import React, { useEffect, useState, useCallback } from 'react';
import apiClient from '../api/axiosConfig';
import Pagination from '../components/common/Pagination';
import '../assets/css/VoterList.css';

const VoterList = () => {
  const [voters, setVoters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [votersPerPage] = useState(20); // 📄 More voters per page
  const [searchTerm, setSearchTerm] = useState('');

  const fetchVoters = useCallback(async () => {
    setLoading(true);
    try {
      const endpoint = searchTerm ? '/voters/search' : '/voters';
      const payload = searchTerm ? { method: 'POST', data: { name: searchTerm } } : { method: 'GET' };
      const response = await apiClient(endpoint, payload);
      setVoters(response.data);
    } catch (error) {
      console.error("Failed to fetch voters", error);
    } finally {
      setLoading(false);
    }
  }, [searchTerm]);

  useEffect(() => {
    const searchDebounce = setTimeout(() => fetchVoters(), 300);
    return () => clearTimeout(searchDebounce);
  }, [searchTerm, fetchVoters]);

  const indexOfLastVoter = currentPage * votersPerPage;
  const indexOfFirstVoter = indexOfLastVoter - votersPerPage;
  const currentVoters = voters.slice(indexOfFirstVoter, indexOfLastVoter);
  const totalPages = Math.ceil(voters.length / votersPerPage);

  return (
    <div className="voter-list-container">
      <div className="voter-list-header">
        <h2>Voter Database</h2>
        <input
          type="text"
          placeholder="🔍 Search by name..."
          className="search-input"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <div className="table-responsive">
        <table className="voter-table">
          <thead>
            <tr>
              <th>Serial</th>
              <th>Name</th>
              <th>Relation</th>
              <th>House No.</th>
              <th>Age</th>
              <th>Gender</th>
              <th>EPIC Number</th>
              <th>Booth</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan="8">Loading...</td></tr>
            ) : (
              currentVoters.map(voter => (
                <tr key={voter.id}>
                  <td>{voter.serial}</td>
                  <td>{voter.name}</td>
                  <td>{voter.relation}</td>
                  <td>{voter.house_number}</td>
                  <td>{voter.age}</td>
                  <td>{voter.gender}</td>
                  <td>{voter.epic_number}</td>
                  <td>{voter.booth_number}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      )}
    </div>
  );
};

export default VoterList;